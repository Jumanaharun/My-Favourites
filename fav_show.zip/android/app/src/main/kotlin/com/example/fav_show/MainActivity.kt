package com.example.fav_show

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
