//anime name
String anime_name1 = "Detective Conan";
String anime_name2 = "Death note";
String anime_name3 = "Boku dake ga inai machi";

String image1 = "conan2.PNG";
String image2 = "death_note.PNG";
String image3 = "erased.png";

String imdb1 = "8.5";
String imdb2 = "8.9";
String imdb3 = "8.4";

String genre1 = "Shounen, Mystery, Thriller, Police";
String genre2 = "Mystery, Psychological, Shounen, Thriller";
String genre3 = "Suspense, Mystery, Drama";

String desc1 =
    "The story follows the adventures of Shinichi Kudo (also known as Jimmy Kudo in Case Closed), a young detective prodigy who was inadvertently shrunk into a child's body due to a poison he was force-fed by members of a criminal syndicate. Neighbor and family friend Professor Agasa strongly suggested Shinichi hide his identity to prevent them from killing him and the people he cares about, so Shinichi takes the name Conan Edogawa. He goes to live with his childhood friend Ran Mouri and her father, Kogoro, and tries to use Kogoro's detective agency as a way to find the people who shrank him—without letting Ran figure out who he really is.";
String desc2 =
    "After an intelligent yet cynical high school student begins to cleanse the world from evil with the help of a magical notebook that can kill anyone whose name is written on it, international authorities call upon a mysterious detective known as 'L' to thwart his efforts.";
String desc3 =
    "29-year-old Satoru Fujinuma is sent back in time 18 years to prevent the events leading to his mother's death, which began with a series of kidnappings while he was in 5th grade.";
